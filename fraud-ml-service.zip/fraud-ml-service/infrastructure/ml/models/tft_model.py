"""
HarisAI — TFTModel (Temporal Fusion Transformer simplifié)
============================================================
Détecte les patterns de fraude temporels — structuring, layering.

PROBLÈME QU'IL RÉSOUT :
    XGBoost analyse chaque transaction individuellement.
    Un fraudeur qui envoie 9 800 MRU chaque jour passe inaperçu.
    TFT voit les 10 dernières transactions ensemble et détecte le pattern.

ARCHITECTURE :
    Input  → séquence des N dernières transactions du client
    LSTM   → capture les dépendances temporelles
    Attention → pondère les transactions les plus importantes
    Output → score de risque temporel 0.0 → 1.0

UTILISATION DANS L'ENSEMBLE :
    Score TFT = 25% du score final
    Principal modèle AML pour structuring et layering

DONNÉES NÉCESSAIRES :
    Historique des 10 dernières transactions depuis Redis
    Clé : harisai:history:{OPERATOR}:{client_token}
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import pickle
from typing import List, Optional

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from application.ports.i_model import IFraudModel
from domain import ClientProfile, Transaction

logger = logging.getLogger(__name__)

# Taille de la séquence — 10 dernières transactions
SEQUENCE_LENGTH = 10

# Features utilisées par TFT — plus simples que XGBoost
# On n'a pas besoin des 22 features — juste les temporelles
#
# v1.4.0 — is_new_device et is_new_zone retirées : diagnostic Cohen's d sur
# les vraies données IBM AML (HI-Medium, 32M lignes) a confirmé qu'elles sont
# CONSTANTES à 0.0 (le dataset n'a pas de device_id ni de zone géographique),
# donc 0% de signal possible, peu importe le volume de données. Remplacées
# par is_new_beneficiary, qui a montré le signal le plus fort jamais mesuré
# sur ce projet (Cohen's d=1.493 sur GNN_FEATURE_NAMES — 73,3% des fraudes
# ont un nouveau bénéficiaire contre 14,0% des transactions normales) et
# qui était absente de TFT_FEATURE_NAMES sans raison établie.
TFT_FEATURE_NAMES = [
    "amount",
    "hour_of_day",
    "day_of_week",
    "is_night",
    "is_weekend",
    "sim_changed_72h",
    "amount_z_score",
    "is_new_beneficiary",
    "ratio_to_avg",
    # Les 5 features ci-dessous sont les AML_FEATURE_NAMES entraînables
    # (voir feature_engineering.py) — UNIQUEMENT via IBMAMLLoader.
    # load_with_aml_features() (voir train_tft.py). PaySim/Aryan ne
    # peuvent pas les produire (pas de comptes récurrents ni de vraies
    # relations expéditeur→destinataire). near_threshold_flag et
    # round_amount_flag sont volontairement EXCLUES — seuils en MRU
    # inadaptés aux montants multi-devises d'IBM AML (voir
    # ibm_aml_loader.py::load_with_aml_features()).
    # NÉCESSITE un ré-entraînement complet (TFT_INPUT_SIZE 9→14) —
    # charger un ancien .pkl entraîné à une dimension différente
    # échouera bruyamment (RuntimeError PyTorch, mismatch de dimension,
    # soit à load() soit au premier predict() selon le format de
    # sauvegarde) plutôt que silencieusement.
    "is_mule_pattern",
    "tx_velocity_ratio",
    "amount_cumul_ratio",
    "rapid_transfer_flag",
    "many_beneficiaries_flag",
]

TFT_INPUT_SIZE  = len(TFT_FEATURE_NAMES)  # 14 features (était 9)
TFT_HIDDEN_SIZE = 16                       # réduit — plus rapide à converger
TFT_NUM_LAYERS  = 1                        # 1 couche — évite l'underfitting
TFT_OUTPUT_SIZE = 1                        # score 0→1


def normalize_tft_features(arr: np.ndarray) -> np.ndarray:
    """
    Normalise la feature "amount" (toujours en première position dans
    TFT_FEATURE_NAMES) via log1p, AVANT de passer les features au LSTM.

    POURQUOI CETTE NORMALISATION EST NÉCESSAIRE :
        Un diagnostic a confirmé qu'un signal réel et fort existe dans
        "amount" (un arbre de décision simple atteint AUC=0.9999 sur
        cette seule feature), mais le LSTM n'apprenait rien (AUC≈0.5)
        une fois la fuite structurelle de build_sequences() corrigée.
        Cause identifiée : amount brut va jusqu'à plusieurs dizaines de
        milliers, alors que les autres features TFT (amount_z_score,
        ratio_to_avg, flags binaires) restent sur des échelles à un ou
        deux chiffres. Cet écart d'échelle sature les gradients du
        réseau — un problème classique de réseaux de neurones, sans
        lien avec la qualité du signal lui-même.

    log1p (log(1+x)) est préféré à une z-score classique car il ne
    nécessite pas de stocker des statistiques (moyenne/écart-type) du
    train set à part — la transformation est directement réversible et
    déterministe, donc strictement identique à l'entraînement et en
    production sans aucun risque de désynchronisation des stats.

    Args:
        arr : array de features TFT, shape (..., TFT_INPUT_SIZE),
              "amount" doit être à l'index 0 (voir TFT_FEATURE_NAMES)

    Returns:
        Le même array, avec la colonne "amount" transformée en log1p.
        Modifie une COPIE — ne mute jamais l'array d'entrée.
    """
    arr = arr.copy()
    amount_idx = TFT_FEATURE_NAMES.index("amount")
    arr[..., amount_idx] = np.log1p(np.clip(arr[..., amount_idx], 0, None))
    return arr


# ─────────────────────────────────────────────
# ARCHITECTURE PYTORCH
# ─────────────────────────────────────────────

class TFTNetwork(nn.Module):
    """
    Réseau de neurones LSTM + Attention pour l'analyse temporelle.

    Architecture :
        Input (seq_len, batch, features)
            ↓
        LSTM (bidirectionnel)
            ↓
        Attention (self-attention sur la séquence)
            ↓
        Linear → Sigmoid → score 0→1
    """

    def __init__(
        self,
        input_size: int = TFT_INPUT_SIZE,
        hidden_size: int = TFT_HIDDEN_SIZE,
        num_layers: int = TFT_NUM_LAYERS,
    ):
        super().__init__()

        # LSTM bidirectionnel — capture les patterns passés et futurs
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=0.1 if num_layers > 1 else 0.0,
        )

        # Couche d'attention — pondère les timesteps importants
        self.attention = nn.Linear(hidden_size * 2, 1)

        # Couche de sortie
        #
        # HISTORIQUE — v1.5.0 avait un surapprentissage marqué (val_loss
        # triple après ~epoch 20-30, HI-Small, 100 epochs, 5 features AML
        # ajoutées). Diagnostic : ~1900 séquences de fraude uniques
        # réutilisées jusqu'à 4×/epoch sur 100 epochs (voir
        # max_fraud_repeats_per_epoch dans train() ci-dessous) — le
        # réseau mémorisait ces séquences précises plutôt que d'apprendre
        # un pattern généralisable, en partie parce que le LSTM n'a jamais
        # de dropout interne actif (nn.LSTM n'applique son paramètre
        # dropout qu'ENTRE couches récurrentes — inerte avec num_layers=1,
        # notre cas).
        #
        # Un correctif (dropout=0.3 après le LSTM + bruit gaussien
        # std=0.05 sur TOUTES les features, y compris binaires) a réduit
        # l'écart train/val, MAIS a fait RECULER toutes les métriques
        # réelles par rapport à v1.5.0 sans correctif (comparaison
        # HI-Small, 100 epochs, seuil=0.9) :
        #   val_loss  0.2477 → 0.2862 (pire)
        #   AUC-ROC   0.9642 → 0.9511 (pire)
        #   AUC-PR    0.1807 → 0.1666 (pire)
        #   précision 0.0865 → 0.0789 (pire)
        #   rappel    0.6049 → 0.5752 (pire)
        #   f1        0.1513 → 0.1388 (pire)
        # Sur-correction : 0.3 est trop agressif pour un réseau aussi
        # petit (hidden_size=16), et le bruit uniforme sur des features
        # binaires n'a pas de sens. REVERT COMPLET à l'état d'origine
        # (dropout=0.1, sortie seulement) pour isoler proprement la vraie
        # piste suspectée : min_history=10 exclut ~46% des fraudes brutes
        # de l'entraînement (voir --min-history dans train_tft.py) — un
        # vrai gain de volume de données, pas un compromis biais-variance
        # comme la régularisation. À retester une fois min_history
        # évalué séparément, pour ne pas confondre deux variables dans
        # la même expérience.
        self.output_layer = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size, 1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x : tensor shape (batch, seq_len, features)

        Returns:
            tensor shape (batch, 1) — score 0→1
        """
        # LSTM → (batch, seq_len, hidden*2)
        lstm_out, _ = self.lstm(x)

        # Attention weights → (batch, seq_len, 1)
        attention_weights = torch.softmax(
            self.attention(lstm_out), dim=1
        )

        # Contexte pondéré → (batch, hidden*2)
        context = (lstm_out * attention_weights).sum(dim=1)

        # Score final → (batch, 1)
        return self.output_layer(context)


# ─────────────────────────────────────────────
# MODÈLE PRINCIPAL
# ─────────────────────────────────────────────

class TFTModel(IFraudModel):
    """
    Modèle TFT pour la détection de patterns temporels AML.

    Hérite de IFraudModel — respecte le contrat défini
    dans application/ports/i_model.py.

    Exemple d'utilisation :
        model = TFTModel()
        await model.load("models/tft_v1.0.0.pkl")
        score = await model.predict(tx, profile, features)
    """

    def __init__(self, version: str = "1.0.0"):
        self._network: Optional[TFTNetwork] = None
        self._version = version
        self._is_ready = False
        self._lock = asyncio.Lock()
        # Utilise le GPU automatiquement s'il est disponible (Kaggle
        # Tesla T4, etc.) — auparavant codé en dur sur CPU, ce qui
        # ignorait silencieusement tout GPU présent et ralentissait
        # l'entraînement d'un facteur significatif sans message d'erreur.
        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        # Seuil de décision — 0.5 par défaut, remplacé par le seuil F1
        # optimal trouvé pendant train() (voir best_threshold). Conservé
        # ici pour que predict() puisse l'utiliser après chargement
        # d'un modèle sauvegardé (save()/load() doivent le persister).
        self._decision_threshold = 0.5
        logger.info("TFTModel initialisé", extra={"version": version})

    # ── Propriétés ────────────────────────────

    @property
    def model_name(self) -> str:
        return "tft_aml"

    @property
    def model_version(self) -> str:
        return self._version

    # ── Chargement ────────────────────────────

    async def load(self, model_path: str) -> None:
        """
        Charge le réseau depuis un fichier pickle ou .pt.

        Rétrocompatible avec les anciens modèles (v1.3.0 et antérieurs)
        sauvegardés avant l'ajout du seuil de décision optimal — dans ce
        cas, self._decision_threshold reste à 0.5 (valeur par défaut de
        __init__), car ces anciens fichiers ne contiennent que le réseau.
        """
        try:
            if model_path.endswith(".pt"):
                checkpoint = torch.load(model_path, map_location=self._device)
                self._network = TFTNetwork()
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    self._network.load_state_dict(checkpoint["state_dict"])
                    self._decision_threshold = checkpoint.get("decision_threshold", 0.5)
                else:
                    # Ancien format — checkpoint est directement le state_dict
                    self._network.load_state_dict(checkpoint)
            else:
                with open(model_path, "rb") as f:
                    loaded = pickle.load(f)
                if isinstance(loaded, dict) and "network" in loaded:
                    self._network = loaded["network"]
                    self._decision_threshold = loaded.get("decision_threshold", 0.5)
                else:
                    # Ancien format — loaded est directement le réseau
                    self._network = loaded

            self._network = self._network.to(self._device)
            self._network.eval()
            self._is_ready = True
            logger.info(
                "TFTModel chargé",
                extra={"path": model_path, "decision_threshold": self._decision_threshold, "device": str(self._device)}
            )

        except FileNotFoundError:
            logger.error(f"Fichier TFT introuvable : {model_path}")
            raise
        except Exception as e:
            logger.error(f"Erreur chargement TFT : {e}")
            raise

    def load_from_network(self, network: TFTNetwork) -> None:
        """Charge directement depuis un objet TFTNetwork entraîné."""
        self._network = network
        self._network.eval()
        self._is_ready = True
        logger.info("TFTModel chargé depuis network")

    async def is_ready(self) -> bool:
        return self._is_ready

    # ── Prédiction ────────────────────────────

    async def predict(
        self,
        transaction: Transaction,
        profile: ClientProfile,
        features: dict,
    ) -> float:
        """
        Prédit le score de risque temporel.

        Construit une séquence de 10 transactions depuis Redis
        (ou synthétique si pas d'historique) et prédit avec le LSTM.

        Returns:
            float entre 0.0 (pattern normal) et 1.0 (pattern suspect)
        """
        if not self._is_ready:
            logger.debug("TFTModel non chargé — retourne 0.0")
            return 0.0

        # Construit la séquence temporelle
        sequence = self._build_sequence(transaction, profile, features)

        # Convertit en tensor PyTorch
        X = torch.tensor(
            sequence, dtype=torch.float32, device=self._device
        ).unsqueeze(0)  # (1, seq_len, features)

        async with self._lock:
            with torch.no_grad():
                score = self._network(X).item()

        logger.debug(
            "Prédiction TFT",
            extra={
                "transaction_id": transaction.transaction_id,
                "score":          round(score, 4),
            }
        )

        return float(score)

    # ── Entraînement ──────────────────────────

    def train(
        self,
        sequences: np.ndarray,
        labels: np.ndarray,
        epochs: int = 50,
        learning_rate: float = 0.001,
        batch_size: int = 256,
    ) -> dict:
        """
        Entraîne le réseau LSTM + Attention.

        Args:
            sequences : array shape (n_samples, seq_len, n_features)
            labels    : array shape (n_samples,) — 0=normal · 1=fraude
            epochs    : nombre d'epochs d'entraînement
            learning_rate : taux d'apprentissage
            batch_size    : taille des batches

        Returns:
            dict avec les métriques finales
        """
        logger.info(
            "Début entraînement TFT",
            extra={
                "n_samples": len(sequences),
                "epochs":    epochs,
                "seq_len":   sequences.shape[1],
            }
        )

        self._network = TFTNetwork().to(self._device)
        self._network.train()
        logger.info(f"Entraînement TFT sur device : {self._device}")

        # Gestion déséquilibre fraude/normal — calculé une fois, appliqué
        # par échantillon à chaque batch (voir boucle ci-dessous). BCELoss
        # n'a pas de paramètre pos_weight comme BCEWithLogitsLoss ; il faut
        # construire un tensor de poids par échantillon à chaque appel.
        n_normal = (labels == 0).sum()
        n_fraud  = (labels == 1).sum()
        pos_weight_value = float(n_normal / max(n_fraud, 1))

        # CORRECTIF — le réseau a déjà un nn.Sigmoid() en dernière couche
        # (output_layer), donc il retourne une probabilité, pas un logit.
        # BCEWithLogitsLoss attend des logits bruts et applique son propre
        # sigmoid interne — l'utiliser ici créait un double-sigmoïde
        # mathématiquement incorrect (compresse artificiellement les
        # scores vers le centre, fausse le gradient). BCELoss (sans
        # reduction interne) est la loss correcte pour une sortie déjà
        # sigmoïdée ; la pondération des classes se fait via le paramètre
        # weight, recalculé par batch ci-dessous.
        criterion  = nn.BCELoss(reduction="none")
        optimizer  = torch.optim.Adam(
            self._network.parameters(),
            lr=learning_rate,
            weight_decay=1e-4,
        )
        scheduler  = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, patience=5, factor=0.5
        )

        # Normalise amount (log1p) avant l'entraînement — voir
        # normalize_tft_features() pour la justification complète.
        sequences = normalize_tft_features(sequences)

        X = torch.tensor(sequences, dtype=torch.float32, device=self._device)
        y = torch.tensor(labels, dtype=torch.float32, device=self._device).unsqueeze(1)

        # Split train/val
        n_val     = int(len(X) * 0.2)
        X_train, X_val = X[:-n_val], X[-n_val:]
        y_train, y_val = y[:-n_val], y[-n_val:]

        # ── Échantillonnage stratifié par batch ──
        # PROBLÈME RÉSOLU ICI : avec le vrai ratio de fraude IBM AML
        # (~0.07-0.13%), un tirage séquentiel ou aléatoire simple produit
        # des batches dont la majorité ne contient AUCUNE fraude (mesuré :
        # 69% des batches de 512 exemples sur 0.072% de fraude). Le poids
        # énorme (pos_weight_value ~1388) ne s'applique alors qu'à de
        # rares exemples isolés, créant un gradient très bruyant qui fait
        # OSCILLER ou AUGMENTER la loss au lieu de converger (observé :
        # train_loss 1.61→1.84 entre les epochs 10 et 20).
        #
        # Solution : chaque batch est construit explicitement avec une
        # proportion minimale de fraude (fraud_ratio_per_batch), via un
        # tirage AVEC remise côté fraude (il y en a trop peu pour tirer
        # sans remise sur de nombreux batches) et SANS remise côté normal.
        # Ceci ne modifie JAMAIS le contenu des séquences elles-mêmes
        # (toujours le vrai historique chronologique, zéro fuite) — seul
        # l'ORDRE DE PRÉSENTATION des exemples au modèle change, ce qui
        # est une pratique standard pour le déséquilibre extrême, sans
        # rapport avec la fuite structurelle déjà corrigée par ailleurs.
        train_fraud_idx  = (y_train.squeeze(1) == 1).nonzero(as_tuple=True)[0]
        train_normal_idx = (y_train.squeeze(1) == 0).nonzero(as_tuple=True)[0]
        n_train_fraud  = len(train_fraud_idx)
        n_train_normal = len(train_normal_idx)

        fraud_ratio_per_batch = 0.15  # 15% de fraude par batch — équilibre
                                       # suffisant sans devenir aussi artificiel
                                       # que les 25% de l'ancienne construction
        n_fraud_per_batch  = max(1, int(batch_size * fraud_ratio_per_batch))
        n_normal_per_batch = batch_size - n_fraud_per_batch

        # Nombre de batches par epoch — basé sur le volume de normaux
        # (largement majoritaires), pas sur le nombre brut de séquences,
        # pour garder un temps d'epoch raisonnable même sur des millions
        # de séquences (voir aussi le ralentissement mesuré : ~5160
        # itérations/epoch avec l'ancien découpage séquentiel sur 2.6M
        # séquences, dominé par l'overhead Python/CUDA par itération).
        n_batches_per_epoch = max(1, n_train_normal // n_normal_per_batch)
        n_batches_per_epoch = min(n_batches_per_epoch, 500)  # plafond de sécurité

        # ── Plafond supplémentaire — évite la répétition excessive ──
        # PROBLÈME OBSERVÉ : avec n_batches_per_epoch=500 calibré
        # uniquement sur le volume de normaux (énorme), et seulement
        # ~1900 fraudes uniques disponibles en train, chaque exemple de
        # fraude était tiré ~20 fois PAR EPOCH (avec remise) — sur 100
        # epochs, jusqu'à 2000 répétitions du même exemple individuel.
        # Le modèle mémorisait ces cas précis au lieu d'apprendre un
        # pattern généralisable : train_loss descendait (0.20→0.14)
        # tout en val_loss explosait (0.56→1.46), signature classique
        # de l'overfitting. On plafonne désormais le nombre de tirages
        # de fraude par epoch à un multiple raisonnable du volume réel
        # disponible (max_fraud_repeats_per_epoch), ce qui borne aussi
        # n_batches_per_epoch en conséquence.
        max_fraud_repeats_per_epoch = 4
        max_batches_from_fraud_budget = max(
            1,
            (n_train_fraud * max_fraud_repeats_per_epoch) // n_fraud_per_batch
        )
        n_batches_per_epoch = min(n_batches_per_epoch, max_batches_from_fraud_budget)

        if n_train_fraud == 0:
            raise ValueError(
                "Aucune fraude dans le train set — impossible d'entraîner "
                "avec un échantillonnage stratifié. Vérifie le split ou "
                "le dataset source."
            )

        best_val_loss = float("inf")
        best_state    = None

        for epoch in range(epochs):
            # ── Training ───────────────────────
            self._network.train()
            train_losses = []

            for _ in range(n_batches_per_epoch):
                fraud_sample  = train_fraud_idx[
                    torch.randint(0, n_train_fraud, (n_fraud_per_batch,), device=self._device)
                ]
                normal_sample = train_normal_idx[
                    torch.randint(0, n_train_normal, (n_normal_per_batch,), device=self._device)
                ]
                batch_idx = torch.cat([fraud_sample, normal_sample])

                X_batch = X_train[batch_idx]
                y_batch = y_train[batch_idx]

                # NOTE — une augmentation par bruit gaussien sur les
                # exemples de fraude ré-échantillonnés a été testée ici
                # (std=0.05, toutes features) en même temps que le
                # dropout ci-dessus. Retirée avec le dropout — voir
                # l'historique complet dans TFTNetwork.__init__()
                # (docstring de output_layer) pour la comparaison de
                # métriques qui a motivé ce revert.

                optimizer.zero_grad()
                # Le réseau applique déjà Sigmoid() en interne — out
                # est une vraie probabilité entre 0 et 1, pas un logit.
                out = self._network(X_batch)

                # Le sur-échantillonnage ci-dessus gère déjà l'essentiel
                # du déséquilibre — un poids résiduel léger reste utile
                # pour affiner, mais BEAUCOUP plus modéré que pos_weight_value
                # brut (~1388), qui n'a plus de sens une fois les batches
                # déjà équilibrés à 15% de fraude.
                sample_weights = 1.0 + y_batch * (1.0 / fraud_ratio_per_batch - 1.0) * 0.3
                loss = (criterion(out, y_batch) * sample_weights).mean()

                loss.backward()
                nn.utils.clip_grad_norm_(self._network.parameters(), 1.0)
                optimizer.step()
                train_losses.append(loss.item())

            # ── Validation ─────────────────────
            # Découpée par batch — même nécessité que pour l'entraînement.
            # Sur de gros volumes (IBM AML, des centaines de milliers de
            # séquences de validation), passer tout X_val en un seul appel
            # au LSTM peut demander plus de VRAM que disponible (observé :
            # 12.8 GiB requis pour ~660k séquences sur un GPU 14.56 GiB,
            # alors que l'entraînement par petits batches ne posait aucun
            # problème). torch.no_grad() évite déjà le stockage des
            # gradients, mais les activations intermédiaires du LSTM
            # restent proportionnelles à la taille du batch traité.
            self._network.eval()
            val_losses_weighted = []
            val_weights_sum = []
            with torch.no_grad():
                for i in range(0, len(X_val), batch_size):
                    xb = X_val[i:i + batch_size]
                    yb = y_val[i:i + batch_size]
                    out = self._network(xb)
                    w = 1.0 + yb * (pos_weight_value - 1.0)
                    val_losses_weighted.append((criterion(out, yb) * w).sum().item())
                    val_weights_sum.append(w.sum().item())
            val_loss = sum(val_losses_weighted) / sum(val_weights_sum)

            scheduler.step(val_loss)

            # Sauvegarde le meilleur modèle
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state    = {
                    k: v.clone() for k, v in
                    self._network.state_dict().items()
                }

            if (epoch + 1) % 10 == 0:
                logger.info(
                    f"Epoch {epoch+1}/{epochs} — "
                    f"train_loss={np.mean(train_losses):.4f} "
                    f"val_loss={val_loss:.4f}"
                )

        # Charge le meilleur modèle
        if best_state:
            self._network.load_state_dict(best_state)

        self._network.eval()
        self._is_ready = True

        # ── Métriques de classification sur le MEILLEUR modèle ──
        # Le val_loss seul ne suffit pas : avec ~0.1% de fraude dans
        # IBM AML, un modèle qui prédit toujours "normal" aurait déjà
        # une loss artificiellement basse. Rappel/précision/F1/AUC
        # montrent si le modèle détecte vraiment quelque chose.
        # Découpé par batch — même raison que pour la validation pendant
        # l'entraînement (évite l'OOM sur de gros volumes de validation).
        val_proba_parts = []
        with torch.no_grad():
            for i in range(0, len(X_val), batch_size):
                out = self._network(X_val[i:i + batch_size])
                val_proba_parts.append(out.cpu().numpy().ravel())
        val_proba = np.concatenate(val_proba_parts)
        y_val_np = y_val.cpu().numpy().ravel()

        # Recherche du seuil F1 optimal — même logique que train_xgboost.py.
        # Les échantillons synthétiques sont équilibrés à 25% de fraude
        # (build_sequences()), donc le seuil par défaut 0.5 est rarement
        # le bon point de coupure une fois ramené à un taux de fraude réel.
        best_threshold, best_f1_search = 0.5, 0.0
        for t in np.arange(0.1, 0.95, 0.05):
            f1_t = f1_score(y_val_np, (val_proba >= t).astype(int), zero_division=0)
            if f1_t > best_f1_search:
                best_f1_search, best_threshold = f1_t, t
        best_threshold = float(round(best_threshold, 2))

        val_pred = (val_proba >= best_threshold).astype(int)

        try:
            auc_roc = roc_auc_score(y_val_np, val_proba)
        except ValueError:
            # Cas limite : aucune fraude dans le split de validation
            auc_roc = float("nan")

        metrics = {
            "status":        "trained",
            "epochs":        epochs,
            "best_val_loss": round(best_val_loss, 4),
            "n_samples":     len(sequences),
            "threshold":     best_threshold,
            "auc_roc":       round(auc_roc, 4) if not np.isnan(auc_roc) else None,
            "auc_pr":        round(average_precision_score(y_val_np, val_proba), 4),
            "precision":     round(precision_score(y_val_np, val_pred, zero_division=0), 4),
            "recall":        round(recall_score(y_val_np, val_pred, zero_division=0), 4),
            "f1":            round(f1_score(y_val_np, val_pred, zero_division=0), 4),
        }

        # Mémorise le seuil retenu pour predict() — voir plus bas
        self._decision_threshold = best_threshold

        logger.info("TFT entraîné", extra=metrics)
        return metrics

    def save(self, path: str) -> None:
        """
        Sauvegarde le réseau entraîné ET le seuil de décision optimal.

        Le seuil est sauvegardé dans un dict avec le state_dict du réseau
        (pas dans un fichier séparé) pour qu'il ne puisse jamais être
        désynchronisé d'avec le modèle auquel il correspond.
        """
        if not self._is_ready:
            raise RuntimeError("Aucun modèle TFT à sauvegarder")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if path.endswith(".pt"):
            torch.save(
                {
                    "state_dict": self._network.state_dict(),
                    "decision_threshold": self._decision_threshold,
                },
                path,
            )
        else:
            with open(path, "wb") as f:
                pickle.dump(
                    {
                        "network": self._network,
                        "decision_threshold": self._decision_threshold,
                    },
                    f,
                )
        logger.info(
            f"TFTModel sauvegardé → {path}",
            extra={"decision_threshold": self._decision_threshold}
        )

    # ── Méthodes privées ──────────────────────

    def _build_sequence(
        self,
        transaction: Transaction,
        profile: ClientProfile,
        features: dict,
    ) -> np.ndarray:
        """
        Construit une séquence de SEQUENCE_LENGTH transactions.

        La transaction actuelle est la dernière de la séquence.
        Les transactions précédentes sont simulées depuis le profil
        (en production elles viennent de Redis history).

        Returns:
            numpy array shape (SEQUENCE_LENGTH, TFT_INPUT_SIZE)
        """
        # Features de la transaction actuelle
        current = self._extract_tft_features(features)

        # Simule l'historique depuis le profil
        # En production : lire depuis Redis harisai:history:...
        history = self._simulate_history(profile, current)

        # Construit la séquence : [t-9, t-8, ..., t-1, t_current]
        sequence = history + [current]
        sequence = sequence[-SEQUENCE_LENGTH:]

        # Padding si moins de SEQUENCE_LENGTH transactions
        while len(sequence) < SEQUENCE_LENGTH:
            sequence.insert(0, [0.0] * TFT_INPUT_SIZE)

        arr = np.array(sequence, dtype=np.float32)
        # Même normalisation qu'à l'entraînement — voir
        # normalize_tft_features() pour la justification complète.
        # CRITIQUE : doit toujours être appliquée ici exactement comme
        # dans train(), sinon le modèle reçoit une distribution
        # différente de celle sur laquelle il a appris.
        return normalize_tft_features(arr)

        return np.array(sequence, dtype=np.float32)

    def _extract_tft_features(self, features: dict) -> List[float]:
        """Extrait les features TFT depuis le dict de features complet."""
        return [
            float(features.get(name, 0.0))
            for name in TFT_FEATURE_NAMES
        ]

    def _simulate_history(
        self,
        profile: ClientProfile,
        current: List[float],
    ) -> List[List[float]]:
        """
        Simule l'historique des transactions depuis le profil.
        En production : remplacé par la lecture Redis.

        Génère SEQUENCE_LENGTH-1 transactions historiques
        basées sur les statistiques du profil.
        """
        history = []
        n = min(SEQUENCE_LENGTH - 1, profile.total_transactions)

        for i in range(n):
            # Transaction historique typique pour ce client
            hist_tx = [
                profile.avg_amount_30d,          # amount
                float(
                    profile.usual_hours[i % len(profile.usual_hours)]
                    if profile.usual_hours else 9
                ),                               # hour_of_day
                float(i % 7),                   # day_of_week
                0.0,                             # is_night
                0.0,                             # is_weekend
                0.0,                             # sim_changed_72h
                0.0,                             # amount_z_score (normal)
                0.0,                             # is_new_device
                0.0,                             # is_new_zone
                1.0,                             # ratio_to_avg (normal = 1.0)
            ]
            history.append(hist_tx)

        return history