"""
HarisAI — IsolationForestModel
================================
Détection d'anomalies non supervisée.
Détecte les fraudes nouvelles que XGBoost ne connaît pas encore.

DIFFÉRENCE AVEC XGBOOST :
    XGBoost      → supervisé · apprend sur fraudes labellisées connues
    IsoForest    → non supervisé · apprend uniquement sur transactions normales
                   détecte tout ce qui s'écarte du comportement normal

UTILISATION DANS L'ENSEMBLE :
    Score IsoForest = 20% du score final
    Complète XGBoost pour les fraudes émergentes

ENTRAÎNEMENT :
    Entraîné uniquement sur les transactions normales (Class=0)
    Ne voit jamais les exemples de fraude pendant l'entraînement
    → Apprend le "territoire normal" et signale tout ce qui en sort
"""

from __future__ import annotations

import asyncio
import logging
import os
import pickle
from typing import Optional

import numpy as np
from sklearn.ensemble import IsolationForest

from application.ports.i_model import IFraudModel
from domain import ClientProfile, Transaction
from infrastructure.ml.models.xgboost_model import FEATURE_NAMES

logger = logging.getLogger(__name__)

# Contamination — proportion d'anomalies attendue dans les données
# creditcard.csv : 0.173% · pysim.csv : 0.129%
# On utilise 0.01 (1%) — légèrement plus élevé pour plus de sensibilité
DEFAULT_CONTAMINATION = 0.01


class IsolationForestModel(IFraudModel):
    """
    Modèle Isolation Forest pour la détection d'anomalies.

    Hérite de IFraudModel — respecte le contrat défini
    dans application/ports/i_model.py.

    Exemple d'utilisation :
        model = IsolationForestModel()
        await model.load("models/isolation_forest_v1.0.0.pkl")
        score = await model.predict(tx, profile, features)
    """

    def __init__(self, version: str = "1.0.0"):
        self._model: Optional[IsolationForest] = None
        self._version = version
        self._is_ready = False
        # Lock asyncio — thread-safe
        self._lock = asyncio.Lock()
        logger.info("IsolationForestModel initialisé", extra={"version": version})

    # ── Propriétés obligatoires ───────────────

    @property
    def model_name(self) -> str:
        return "isolation_forest"

    @property
    def model_version(self) -> str:
        return self._version

    # ── Chargement ────────────────────────────

    async def load(self, model_path: str) -> None:
        """Charge le modèle depuis un fichier pickle."""
        try:
            with open(model_path, "rb") as f:
                self._model = pickle.load(f)
            self._is_ready = True
            logger.info(
                "IsolationForest chargé",
                extra={"path": model_path}
            )
        except FileNotFoundError:
            logger.error(f"Fichier modèle introuvable : {model_path}")
            raise
        except Exception as e:
            logger.error(f"Erreur chargement IsolationForest : {e}")
            raise

    def load_from_sklearn(self, model: IsolationForest) -> None:
        """Charge directement depuis un objet sklearn entraîné."""
        self._model = model
        self._is_ready = True
        logger.info("IsolationForest chargé depuis objet sklearn")

    async def is_ready(self) -> bool:
        return self._is_ready

    # ── Prédiction ────────────────────────────

    async def predict(
        self,
        transaction: Transaction,
        profile: ClientProfile,
        features: dict,
    ) -> float:
        """
        Prédit le score d'anomalie pour une transaction.

        Isolation Forest retourne :
            +1 → normal (inlier)
            -1 → anomalie (outlier)

        On convertit en score 0.0 → 1.0 :
            score_normalisé = (score_brut - score_min) / (score_max - score_min)

        Returns:
            float entre 0.0 (normal) et 1.0 (très anormal)
        """
        if not self._is_ready:
            logger.warning("IsolationForest non chargé — retourne 0.0")
            return 0.0

        X = self._features_to_vector(features)

        async with self._lock:
            # decision_function retourne un score de décision
            # Plus le score est négatif → plus c'est une anomalie
            raw_score = self._model.decision_function(X)[0]

        # Convertit en probabilité 0.0 → 1.0
        # decision_function retourne typiquement entre -0.5 et 0.5
        # On normalise : score_normalisé = 1 - (raw_score - min) / (max - min)
        # Approximation : clamp entre -0.5 et 0.5, puis inverser
        normalized = self._normalize_score(raw_score)

        logger.debug(
            "Prédiction IsolationForest",
            extra={
                "transaction_id": transaction.transaction_id,
                "raw_score":      round(float(raw_score), 4),
                "normalized":     round(normalized, 4),
            }
        )

        return normalized

    # ── Entraînement ──────────────────────────

    def train(
        self,
        X_train: np.ndarray,
        n_estimators: int = 200,
        contamination: float = DEFAULT_CONTAMINATION,
        max_samples: str = "auto",
        random_state: int = 42,
    ) -> dict:
        """
        Entraîne le modèle Isolation Forest.

        IMPORTANT : entraîner uniquement sur les transactions NORMALES.
        Le script d'entraînement doit filtrer y_train == 0 avant d'appeler
        cette méthode.

        Args:
            X_train       : features des transactions normales UNIQUEMENT
            n_estimators  : nombre d'arbres (200 par défaut)
            contamination : proportion d'anomalies attendue (0.01 = 1%)
            max_samples   : échantillons par arbre ("auto" = min(256, n))
            random_state  : seed pour reproductibilité

        Returns:
            dict avec les métriques d'entraînement
        """
        logger.info(
            "Début entraînement IsolationForest",
            extra={
                "n_estimators":  n_estimators,
                "contamination": contamination,
                "n_samples":     len(X_train),
            }
        )

        self._model = IsolationForest(
            n_estimators=n_estimators,
            contamination=contamination,
            max_samples=max_samples,
            random_state=random_state,
            n_jobs=-1,          # Utilise tous les CPU
            warm_start=False,
        )

        self._model.fit(X_train)
        self._is_ready = True

        # Calcule le score moyen sur les données d'entraînement
        scores = self._model.decision_function(X_train)
        n_anomalies = (self._model.predict(X_train) == -1).sum()

        metrics = {
            "status":          "trained",
            "n_estimators":    n_estimators,
            "n_samples":       len(X_train),
            "n_anomalies_detected": int(n_anomalies),
            "anomaly_rate":    round(n_anomalies / len(X_train) * 100, 3),
            "score_mean":      round(float(scores.mean()), 4),
            "score_std":       round(float(scores.std()), 4),
        }

        logger.info("IsolationForest entraîné", extra=metrics)
        return metrics

    def save(self, path: str) -> None:
        """Sauvegarde le modèle entraîné."""
        if not self._is_ready:
            raise RuntimeError("Aucun modèle à sauvegarder")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self._model, f)
        logger.info(f"IsolationForest sauvegardé → {path}")

    # ── Méthodes privées ──────────────────────

    def _features_to_vector(self, features: dict) -> np.ndarray:
        """Convertit le dict de features en vecteur numpy ordonné."""
        vector = [
            float(features.get(name, 0.0))
            for name in FEATURE_NAMES
        ]
        return np.array(vector, dtype=np.float32).reshape(1, -1)

    @staticmethod
    def _normalize_score(raw_score: float) -> float:
        """
        Normalise le score de décision Isolation Forest en [0.0, 1.0].

        decision_function retourne :
            Valeurs positives  → normaux (inliers)
            Valeurs négatives  → anomalies (outliers)
            Seuil à 0.0        → frontière de décision

        On convertit :
            score proche de +0.5  → 0.0 (très normal)
            score proche de -0.5  → 1.0 (très anormal)
        """
        # Clamp entre -0.5 et 0.5 (plage typique)
        clamped = max(-0.5, min(0.5, raw_score))
        # Inverse et normalise : anomalie forte → score élevé
        normalized = (0.5 - clamped) / 1.0
        return float(max(0.0, min(1.0, normalized)))