"""
HarisAI — GNNModel (GraphSAGE)
================================
Détecte les réseaux de fraude — layering, comptes mules,
virements coordonnés.

PROBLÈME QU'IL RÉSOUT :
    XGBoost et TFT analysent un compte à la fois.
    Un compte mule reçoit de 10 sources différentes et retransfère
    immédiatement — aucun modèle individuel ne voit ça.
    GNN construit le graphe des relations et détecte les nœuds suspects.

ARCHITECTURE (GraphSAGE) :
    Pour chaque transaction :
        1. Construit un mini-graphe local autour du bénéficiaire
        2. Agrège les features des voisins (mean aggregation)
        3. Combine nœud central + contexte voisins
        4. Prédit le score de risque réseau

    GraphSAGE est choisi car :
        - Fonctionne sans PyTorch Geometric (PyTorch pur)
        - Scalable sur les grands graphes
        - Inductive — fonctionne sur de nouveaux nœuds jamais vus

PATTERNS DÉTECTÉS :
    Layering      → chaîne de transferts A→B→C→Cash
    Compte mule   → fort degré entrant+sortant · zéro solde gardé
    Hub suspect   → reçoit de N sources simultanément
    Réseau coordonné → plusieurs comptes envoient ensemble

UTILISATION DANS L'ENSEMBLE :
    Score GNN = 15% du score final
    Seul modèle qui voit les relations entre comptes
"""

from __future__ import annotations

import asyncio
import logging
import os
import pickle
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)

from application.ports.i_model import IFraudModel
from domain import ClientProfile, Transaction
from infrastructure.ml.models.xgboost_model import FEATURE_NAMES

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# CONSTANTES
# ─────────────────────────────────────────────

# Features utilisées par GNN — focus sur les relations
#
# v1.4.0 — beneficiary_is_merchant et is_dormant_account retirées : diagnostic
# Cohen's d sur les vraies données IBM AML (HI-Medium, 32M lignes) a confirmé
# qu'elles sont CONSTANTES à 0.0 (le dataset bancaire n'a pas de flag marchand
# ni de notion de dormance calculée), donc 0% de signal possible. amount_z_score
# retirée aussi — Cohen's d=0.013, quasi-doublon de amount qui est conservée.
# is_new_beneficiary (Cohen's d=1.493, signal le plus fort mesuré sur ce
# projet) et sim_changed_72h (d=0.408) restent les features les plus utiles.
GNN_FEATURE_NAMES = [
    "amount",
    "is_new_beneficiary",
    "sim_changed_72h",
    "ratio_to_avg",
    "is_new_account",
    # Mêmes 5 features AML entraînables que TFT_FEATURE_NAMES — voir
    # tft_model.py pour le détail complet (source, limites, exclusions).
    # Entraînable UNIQUEMENT via IBMAMLLoader.load_with_aml_features()
    # — voir train_gnn.py. NÉCESSITE un ré-entraînement complet
    # (GNN_INPUT_SIZE 5→10).
    "is_mule_pattern",
    "tx_velocity_ratio",
    "amount_cumul_ratio",
    "rapid_transfer_flag",
    "many_beneficiaries_flag",
]

GNN_INPUT_SIZE  = len(GNN_FEATURE_NAMES)  # 10 features par nœud (était 5)
GNN_HIDDEN_SIZE = 16   # réduit — converge plus vite sur données synthétiques
GNN_OUTPUT_SIZE = 1


def normalize_gnn_features(arr: np.ndarray) -> np.ndarray:
    """
    Normalise la feature "amount" (toujours en première position dans
    GNN_FEATURE_NAMES) via log1p — même correction et même justification
    que normalize_tft_features() dans tft_model.py. Voir ce docstring
    pour le détail complet du problème d'échelle résolu.

    Args:
        arr : array de features GNN, shape (..., GNN_INPUT_SIZE) —
              fonctionne aussi bien sur node_features (..., GNN_INPUT_SIZE)
              que sur neighbor_features (..., n_neighbors, GNN_INPUT_SIZE),
              "amount" doit être à l'index 0 dans les deux cas.

    Returns:
        Le même array, avec la colonne "amount" transformée en log1p.
        Modifie une COPIE — ne mute jamais l'array d'entrée.
    """
    arr = arr.copy()
    amount_idx = GNN_FEATURE_NAMES.index("amount")
    arr[..., amount_idx] = np.log1p(np.clip(arr[..., amount_idx], 0, None))
    return arr
MAX_NEIGHBORS   = 5   # Max voisins à considérer dans le graphe


# ─────────────────────────────────────────────
# ARCHITECTURE PYTORCH (GraphSAGE)
# ─────────────────────────────────────────────

class GraphSAGELayer(nn.Module):
    """
    Couche GraphSAGE — agrège les features des voisins.

    Formule :
        h_v = ReLU(W · CONCAT(h_v, MEAN(h_u for u in N(v))))

    où N(v) = voisins du nœud v dans le graphe de transactions.
    """

    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        # Transformation linéaire sur la concaténation
        # nœud + moyenne voisins → in_features * 2
        self.linear = nn.Linear(in_features * 2, out_features)
        self.norm   = nn.LayerNorm(out_features)

    def forward(
        self,
        node_features: torch.Tensor,
        neighbor_features: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            node_features     : (batch, features) — features du nœud central
            neighbor_features : (batch, n_neighbors, features) — voisins

        Returns:
            (batch, out_features) — représentation enrichie
        """
        # Moyenne des voisins → (batch, features)
        if neighbor_features.size(1) > 0:
            neighbor_agg = neighbor_features.mean(dim=1)
        else:
            neighbor_agg = torch.zeros_like(node_features)

        # Concatène nœud + voisins → (batch, features * 2)
        combined = torch.cat([node_features, neighbor_agg], dim=-1)

        # Transformation + normalisation
        out = F.relu(self.linear(combined))
        return self.norm(out)


class GNNNetwork(nn.Module):
    """
    Réseau GraphSAGE 2 couches pour la détection de fraude réseau.

    Architecture :
        Input (nœud + voisins)
            ↓
        GraphSAGE Layer 1 (input_size → hidden_size)
            ↓
        GraphSAGE Layer 2 (hidden_size → hidden_size//2)
            ↓
        Linear → Sigmoid → score 0→1
    """

    def __init__(
        self,
        input_size: int = GNN_INPUT_SIZE,
        hidden_size: int = GNN_HIDDEN_SIZE,
    ):
        super().__init__()

        self.sage1 = GraphSAGELayer(input_size, hidden_size)
        self.sage2 = GraphSAGELayer(hidden_size, hidden_size // 2)

        # HISTORIQUE — même diagnostic et même revert que TFTNetwork
        # (voir tft_model.py, docstring de output_layer, pour le détail
        # complet et la comparaison de métriques). Un dropout=0.3 après
        # chaque couche GraphSAGE + bruit gaussien sur les exemples de
        # fraude ré-échantillonnés avait été ajouté ici pour la même
        # raison (mémorisation due à max_fraud_repeats_per_epoch=4 sur
        # 100 epochs) — retiré après avoir constaté sur TFT que cette
        # combinaison dégradait toutes les métriques réelles, pas
        # seulement l'écart train/val. REVERT COMPLET à l'état d'origine
        # pour isoler la piste min_history/min_neighbors (voir
        # --min-history / --min-neighbors dans train_tft.py/train_gnn.py).
        self.output = nn.Sequential(
            nn.Linear(hidden_size // 2, hidden_size // 4),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size // 4, 1),
            nn.Sigmoid(),
        )

    def forward(
        self,
        node_features: torch.Tensor,
        neighbor_features_l1: torch.Tensor,
        neighbor_features_l2: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Args:
            node_features         : (batch, GNN_INPUT_SIZE)
            neighbor_features_l1  : (batch, n_neighbors, GNN_INPUT_SIZE)
            neighbor_features_l2  : (batch, n_neighbors, hidden_size) optionnel

        Returns:
            (batch, 1) — score risque réseau 0→1
        """
        # Couche 1 — agrège voisins directs
        h1 = self.sage1(node_features, neighbor_features_l1)

        # Couche 2 — agrège voisins des voisins (si disponibles)
        if neighbor_features_l2 is not None:
            # Transforme les voisins pour la couche 2
            n_batch    = node_features.size(0)
            n_neigh    = neighbor_features_l2.size(1)
            neigh_flat = neighbor_features_l2.view(n_batch * n_neigh, -1)
            neigh_h1   = self.sage1(
                neigh_flat,
                torch.zeros(
                    n_batch * n_neigh, neighbor_features_l2.size(1),
                    GNN_INPUT_SIZE, device=node_features.device,
                )
            )
            neigh_h1 = neigh_h1.view(n_batch, n_neigh, -1)
            h2 = self.sage2(h1, neigh_h1)
        else:
            # BUG CORRIGÉ — torch.zeros() sans device= créait un tensor
            # sur CPU par défaut, alors que node_features/h1 étaient sur
            # cuda:0 dès que l'entraînement tournait sur GPU. RuntimeError
            # "Expected all tensors to be on the same device" dans
            # GraphSAGELayer.forward() (torch.cat plus loin). Invisible
            # tant que l'entraînement tournait sur CPU (tout par défaut
            # sur CPU, aucun conflit) — révélé par le premier run réel
            # sur GPU (Tesla T4, Kaggle, v1.5.0). Ce bug est préexistant,
            # antérieur à toute modification de ce fichier dans le cadre
            # de ce travail — confirmé par diff contre la version reçue
            # initialement.
            h2 = self.sage2(
                h1,
                torch.zeros(
                    node_features.size(0), 1, GNN_HIDDEN_SIZE,
                    device=node_features.device,
                )
            )

        return self.output(h2)


# ─────────────────────────────────────────────
# MODÈLE PRINCIPAL
# ─────────────────────────────────────────────

class GNNModel(IFraudModel):
    """
    Modèle GNN pour la détection de réseaux de fraude.

    Hérite de IFraudModel — respecte le contrat défini
    dans application/ports/i_model.py.

    Exemple d'utilisation :
        model = GNNModel()
        await model.load("models/gnn_v1.0.0.pkl")
        score = await model.predict(tx, profile, features)
    """

    def __init__(self, version: str = "1.0.0"):
        self._network: Optional[GNNNetwork] = None
        self._version = version
        self._is_ready = False
        self._lock = asyncio.Lock()
        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        # Seuil de décision — 0.5 par défaut, remplacé par le seuil F1
        # optimal trouvé pendant train(). Persisté par save()/load().
        self._decision_threshold = 0.5
        logger.info("GNNModel initialisé", extra={"version": version})

    # ── Propriétés ────────────────────────────

    @property
    def model_name(self) -> str:
        return "gnn_network"

    @property
    def model_version(self) -> str:
        return self._version

    # ── Chargement ────────────────────────────

    async def load(self, model_path: str) -> None:
        """
        Charge le réseau depuis un fichier.

        Rétrocompatible avec les anciens modèles (v1.3.0 et antérieurs)
        sauvegardés avant l'ajout du seuil de décision optimal.
        """
        try:
            if model_path.endswith(".pt"):
                checkpoint = torch.load(model_path, map_location=self._device)
                self._network = GNNNetwork()
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    self._network.load_state_dict(checkpoint["state_dict"])
                    self._decision_threshold = checkpoint.get("decision_threshold", 0.5)
                else:
                    self._network.load_state_dict(checkpoint)
            else:
                with open(model_path, "rb") as f:
                    loaded = pickle.load(f)
                if isinstance(loaded, dict) and "network" in loaded:
                    self._network = loaded["network"]
                    self._decision_threshold = loaded.get("decision_threshold", 0.5)
                else:
                    self._network = loaded

            self._network = self._network.to(self._device)
            self._network.eval()
            self._is_ready = True
            logger.info(
                "GNNModel chargé",
                extra={"path": model_path, "decision_threshold": self._decision_threshold, "device": str(self._device)}
            )

        except FileNotFoundError:
            logger.error(f"Fichier GNN introuvable : {model_path}")
            raise
        except Exception as e:
            logger.error(f"Erreur chargement GNN : {e}")
            raise

    def load_from_network(self, network: GNNNetwork) -> None:
        """Charge directement depuis un objet GNNNetwork entraîné."""
        self._network = network
        self._network.eval()
        self._is_ready = True

    async def is_ready(self) -> bool:
        return self._is_ready

    # ── Prédiction ────────────────────────────

    async def predict(
        self,
        transaction: Transaction,
        profile: ClientProfile,
        features: dict,
    ) -> float:
        """
        Prédit le score de risque réseau pour une transaction.

        Construit un mini-graphe local :
            - Nœud central = bénéficiaire de la transaction
            - Voisins = autres clients qui ont envoyé à ce bénéficiaire

        Returns:
            float entre 0.0 (réseau normal) et 1.0 (réseau suspect)
        """
        if not self._is_ready:
            logger.debug("GNNModel non chargé — retourne 0.0")
            return 0.0

        # Features du nœud central (bénéficiaire)
        node_feat = self._extract_gnn_features(features)

        # Features des voisins (simulées depuis le profil)
        # En production : lire depuis Redis harisai:graph:...
        neighbor_feat = self._simulate_neighbor_features(
            transaction, profile, features
        )

        # Convertit en tensors
        # Normalise amount (log1p) — même transformation qu'à
        # l'entraînement, voir normalize_gnn_features(). CRITIQUE :
        # doit toujours être appliquée ici exactement comme dans
        # train(), sinon le modèle reçoit une distribution différente
        # de celle sur laquelle il a appris.
        node_tensor = torch.tensor(
            normalize_gnn_features(np.array([node_feat], dtype=np.float32)),
            dtype=torch.float32, device=self._device
        )  # (1, GNN_INPUT_SIZE)

        neigh_tensor = torch.tensor(
            normalize_gnn_features(np.array([neighbor_feat], dtype=np.float32)),
            dtype=torch.float32, device=self._device
        )  # (1, n_neighbors, GNN_INPUT_SIZE)

        async with self._lock:
            with torch.no_grad():
                score = self._network(
                    node_tensor,
                    neigh_tensor,
                ).item()

        logger.debug(
            "Prédiction GNN",
            extra={
                "transaction_id": transaction.transaction_id,
                "score":          round(score, 4),
                "n_neighbors":    len(neighbor_feat),
            }
        )

        return float(score)

    # ── Entraînement ──────────────────────────

    def train(
        self,
        node_features: np.ndarray,
        neighbor_features: np.ndarray,
        labels: np.ndarray,
        epochs: int = 50,
        learning_rate: float = 0.001,
        batch_size: int = 256,
    ) -> dict:
        """
        Entraîne le réseau GNN.

        Args:
            node_features     : (n, GNN_INPUT_SIZE) — features nœud central
            neighbor_features : (n, MAX_NEIGHBORS, GNN_INPUT_SIZE) — voisins
            labels            : (n,) — 0=normal · 1=fraude réseau
            epochs            : nombre d'epochs
            learning_rate     : taux d'apprentissage
            batch_size        : taille des batches

        Returns:
            dict avec métriques d'entraînement
        """
        logger.info(
            "Début entraînement GNN",
            extra={
                "n_samples": len(node_features),
                "epochs":    epochs,
            }
        )

        self._network = GNNNetwork().to(self._device)
        self._network.train()
        logger.info(f"Entraînement GNN sur device : {self._device}")

        # Gestion déséquilibre — calculé une fois, appliqué par échantillon
        # à chaque batch. BCELoss n'a pas de paramètre pos_weight comme
        # BCEWithLogitsLoss ; il faut pondérer manuellement.
        n_normal = (labels == 0).sum()
        n_fraud  = (labels == 1).sum()
        pos_weight_value = float(n_normal / max(n_fraud, 1))

        # CORRECTIF — le réseau a déjà un nn.Sigmoid() en dernière couche
        # (voir output_layer), donc il retourne une probabilité, pas un
        # logit. BCEWithLogitsLoss attend des logits bruts et applique son
        # propre sigmoid interne — l'utiliser ici créait un double-sigmoïde
        # mathématiquement incorrect. BCELoss (reduction="none") est la
        # loss correcte pour une sortie déjà sigmoïdée ; la pondération
        # des classes se fait via un tensor de poids recalculé par batch.
        criterion = nn.BCELoss(reduction="none")
        optimizer = torch.optim.Adam(
            self._network.parameters(),
            lr=learning_rate,
            weight_decay=1e-4,
        )

        # Normalise amount (log1p) avant l'entraînement — même correction
        # que TFT, voir normalize_gnn_features() pour la justification.
        node_features     = normalize_gnn_features(node_features)
        neighbor_features = normalize_gnn_features(neighbor_features)

        X_node  = torch.tensor(node_features, dtype=torch.float32, device=self._device)
        X_neigh = torch.tensor(neighbor_features, dtype=torch.float32, device=self._device)
        y       = torch.tensor(labels, dtype=torch.float32, device=self._device).unsqueeze(1)

        # Split train/val
        n_val       = int(len(X_node) * 0.2)
        X_n_train, X_n_val = X_node[:-n_val], X_node[-n_val:]
        X_e_train, X_e_val = X_neigh[:-n_val], X_neigh[-n_val:]
        y_train,   y_val   = y[:-n_val], y[-n_val:]

        # ── Échantillonnage stratifié par batch ──
        # Même correction que TFT (voir tft_model.py train() pour le
        # détail complet du problème résolu) : avec le vrai ratio de
        # fraude IBM AML, un tirage séquentiel produit des batches
        # majoritairement sans aucune fraude, créant un gradient bruyant
        # qui empêche la convergence. Le contenu des échantillons graphe
        # reste inchangé (toujours le vrai graphe de transferts, zéro
        # fuite) — seul l'ordre de présentation au modèle change.
        train_fraud_idx  = (y_train.squeeze(1) == 1).nonzero(as_tuple=True)[0]
        train_normal_idx = (y_train.squeeze(1) == 0).nonzero(as_tuple=True)[0]
        n_train_fraud  = len(train_fraud_idx)
        n_train_normal = len(train_normal_idx)

        fraud_ratio_per_batch = 0.15
        n_fraud_per_batch  = max(1, int(batch_size * fraud_ratio_per_batch))
        n_normal_per_batch = batch_size - n_fraud_per_batch

        n_batches_per_epoch = max(1, n_train_normal // n_normal_per_batch)
        n_batches_per_epoch = min(n_batches_per_epoch, 500)

        # ── Plafond supplémentaire — évite la répétition excessive ──
        # Même correction que TFT (voir tft_model.py train() pour le
        # détail complet de l'overfitting observé sur les vraies données
        # IBM AML : train_loss descendait pendant que val_loss explosait,
        # car chaque exemple de fraude unique était répété ~20x par
        # epoch faute de ce plafond).
        max_fraud_repeats_per_epoch = 4
        max_batches_from_fraud_budget = max(
            1,
            (n_train_fraud * max_fraud_repeats_per_epoch) // n_fraud_per_batch
        )
        n_batches_per_epoch = min(n_batches_per_epoch, max_batches_from_fraud_budget)

        if n_train_fraud == 0:
            raise ValueError(
                "Aucune fraude dans le train set — impossible d'entraîner "
                "avec un échantillonnage stratifié. Vérifie le split ou "
                "le dataset source."
            )

        best_val_loss = float("inf")
        best_state    = None

        for epoch in range(epochs):
            self._network.train()
            train_losses = []

            for _ in range(n_batches_per_epoch):
                fraud_sample  = train_fraud_idx[
                    torch.randint(0, n_train_fraud, (n_fraud_per_batch,), device=self._device)
                ]
                normal_sample = train_normal_idx[
                    torch.randint(0, n_train_normal, (n_normal_per_batch,), device=self._device)
                ]
                batch_idx = torch.cat([fraud_sample, normal_sample])

                xn = X_n_train[batch_idx]
                xe = X_e_train[batch_idx]
                yb = y_train[batch_idx]

                # NOTE — une augmentation par bruit gaussien (nœud +
                # voisins) sur les exemples de fraude ré-échantillonnés a
                # été testée ici en même temps que le dropout ci-dessus.
                # Retirée avec le dropout — voir l'historique complet
                # dans GNNNetwork.__init__() pour la comparaison de
                # métriques (mesurée sur TFT, même mécanisme) qui a
                # motivé ce revert.

                optimizer.zero_grad()
                # Le réseau applique déjà Sigmoid() en interne — out est
                # une vraie probabilité entre 0 et 1, pas un logit.
                out = self._network(xn, xe)

                # Poids résiduel léger — le sur-échantillonnage gère déjà
                # l'essentiel du déséquilibre, voir tft_model.py train()
                # pour la justification complète de ce facteur 0.3.
                sample_weights = 1.0 + yb * (1.0 / fraud_ratio_per_batch - 1.0) * 0.3
                loss = (criterion(out, yb) * sample_weights).mean()

                loss.backward()
                nn.utils.clip_grad_norm_(
                    self._network.parameters(), 1.0
                )
                optimizer.step()
                train_losses.append(loss.item())

            # Validation — découpée par batch, même raison que pour TFT :
            # passer tout X_n_val/X_e_val en un seul appel peut demander
            # plus de VRAM que disponible sur de gros volumes (observé
            # sur TFT : OOM avec ~660k séquences sur un GPU 14.56 GiB).
            self._network.eval()
            val_losses_weighted = []
            val_weights_sum = []
            with torch.no_grad():
                for i in range(0, len(X_n_val), batch_size):
                    xn = X_n_val[i:i + batch_size]
                    xe = X_e_val[i:i + batch_size]
                    yb = y_val[i:i + batch_size]
                    out = self._network(xn, xe)
                    w = 1.0 + yb * (pos_weight_value - 1.0)
                    val_losses_weighted.append((criterion(out, yb) * w).sum().item())
                    val_weights_sum.append(w.sum().item())
            val_loss = sum(val_losses_weighted) / sum(val_weights_sum)

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state    = {
                    k: v.clone()
                    for k, v in self._network.state_dict().items()
                }

            if (epoch + 1) % 10 == 0:
                logger.info(
                    f"Epoch {epoch+1}/{epochs} — "
                    f"train={np.mean(train_losses):.4f} "
                    f"val={val_loss:.4f}"
                )

        if best_state:
            self._network.load_state_dict(best_state)

        self._network.eval()
        self._is_ready = True

        # ── Métriques de classification sur le MEILLEUR modèle ──
        # Même raisonnement que pour TFT : avec ~0.1% de fraude dans
        # IBM AML, le val_loss seul peut masquer un modèle qui ne
        # détecte presque rien. Rappel/précision/F1/AUC le révèlent.
        # Découpé par batch — évite l'OOM sur de gros volumes (voir TFT).
        val_proba_parts = []
        with torch.no_grad():
            for i in range(0, len(X_n_val), batch_size):
                out = self._network(X_n_val[i:i + batch_size], X_e_val[i:i + batch_size])
                val_proba_parts.append(out.cpu().numpy().ravel())
        val_proba = np.concatenate(val_proba_parts)
        y_val_np = y_val.cpu().numpy().ravel()

        # Recherche du seuil F1 optimal — même logique que train_xgboost.py
        # et tft_model.py. Les échantillons synthétiques sont équilibrés à
        # 25% de fraude (build_graph_samples()), donc 0.5 est rarement le
        # bon point de coupure une fois ramené à un taux de fraude réel.
        best_threshold, best_f1_search = 0.5, 0.0
        for t in np.arange(0.1, 0.95, 0.05):
            f1_t = f1_score(y_val_np, (val_proba >= t).astype(int), zero_division=0)
            if f1_t > best_f1_search:
                best_f1_search, best_threshold = f1_t, t
        best_threshold = float(round(best_threshold, 2))

        val_pred = (val_proba >= best_threshold).astype(int)

        try:
            auc_roc = roc_auc_score(y_val_np, val_proba)
        except ValueError:
            # Cas limite : aucune fraude dans le split de validation
            auc_roc = float("nan")

        # ── Courbe précision/rappel complète — voir tft_model.py pour
        # le raisonnement complet (identique ici). ──
        precisions_curve, recalls_curve, thresholds_curve = precision_recall_curve(
            y_val_np, val_proba
        )

        pr_table_lines = ["Seuil | Précision | Rappel | F1"]
        for t in np.arange(0.10, 0.96, 0.05):
            t = round(float(t), 2)
            pred_t = (val_proba >= t).astype(int)
            p_t = precision_score(y_val_np, pred_t, zero_division=0)
            r_t = recall_score(y_val_np, pred_t, zero_division=0)
            f_t = f1_score(y_val_np, pred_t, zero_division=0)
            marker = "  <- retenu" if t == best_threshold else ""
            pr_table_lines.append(
                f"{t:.2f}  | {p_t:.4f}    | {r_t:.4f} | {f_t:.4f}{marker}"
            )
        logger.info(
            "Courbe précision/rappel (grille 0.10-0.95, pas 0.05) :\n"
            + "\n".join(pr_table_lines)
        )

        metrics = {
            "status":        "trained",
            "epochs":        epochs,
            "best_val_loss": round(best_val_loss, 4),
            "n_samples":     len(node_features),
            "threshold":     best_threshold,
            "auc_roc":       round(auc_roc, 4) if not np.isnan(auc_roc) else None,
            "auc_pr":        round(average_precision_score(y_val_np, val_proba), 4),
            "precision":     round(precision_score(y_val_np, val_pred, zero_division=0), 4),
            "recall":        round(recall_score(y_val_np, val_pred, zero_division=0), 4),
            "f1":            round(f1_score(y_val_np, val_pred, zero_division=0), 4),
        }

        pr_curve_data = {
            "precisions": precisions_curve.tolist(),
            "recalls":    recalls_curve.tolist(),
            "thresholds": thresholds_curve.tolist(),
        }

        # Mémorise le seuil retenu pour predict() — voir __init__ et save()
        self._decision_threshold = best_threshold

        logger.info("GNN entraîné", extra=metrics)
        return metrics, pr_curve_data

    def save(self, path: str) -> None:
        """Sauvegarde le réseau entraîné ET le seuil de décision optimal."""
        if not self._is_ready:
            raise RuntimeError("Aucun modèle GNN à sauvegarder")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if path.endswith(".pt"):
            torch.save(
                {
                    "state_dict": self._network.state_dict(),
                    "decision_threshold": self._decision_threshold,
                },
                path,
            )
        else:
            with open(path, "wb") as f:
                pickle.dump(
                    {
                        "network": self._network,
                        "decision_threshold": self._decision_threshold,
                    },
                    f,
                )
        logger.info(
            f"GNNModel sauvegardé → {path}",
            extra={"decision_threshold": self._decision_threshold}
        )

    # ── Méthodes privées ──────────────────────

    def _extract_gnn_features(self, features: dict) -> List[float]:
        """Extrait les features GNN depuis le dict complet."""
        return [
            float(features.get(name, 0.0))
            for name in GNN_FEATURE_NAMES
        ]

    def _simulate_neighbor_features(
        self,
        transaction: Transaction,
        profile: ClientProfile,
        features: dict,
    ) -> List[List[float]]:
        """
        Simule les features des voisins du bénéficiaire.
        En production : lire depuis Redis harisai:graph:...

        Les voisins sont les autres clients qui ont envoyé
        de l'argent à ce même bénéficiaire.

        Pattern compte mule :
            Si le bénéficiaire est nouveau (is_new_beneficiary=True)
            et que c'est un compte récent (is_new_account=True)
            → simule un voisinage suspect (plusieurs sources)
        """
        n_neighbors = min(MAX_NEIGHBORS, profile.total_transactions // 10 + 1)
        neighbors   = []

        is_suspect = (
            features.get("is_new_beneficiary", 0) and
            features.get("is_new_account", 0)
        )

        for i in range(n_neighbors):
            if is_suspect:
                # Voisin suspect — montants élevés, nouvelles relations
                neighbor = [
                    profile.avg_amount_30d * 2,  # amount élevé
                    1.0,                          # is_new_beneficiary
                    0.0,                          # beneficiary_is_merchant
                    0.0,                          # sim_changed_72h
                    2.0,                          # amount_z_score élevé
                    2.0,                          # ratio_to_avg élevé
                    1.0,                          # is_new_account
                    0.0,                          # is_dormant_account
                ]
            else:
                # Voisin normal
                neighbor = [
                    profile.avg_amount_30d,  # amount normal
                    0.0,                     # is_new_beneficiary
                    0.0,                     # beneficiary_is_merchant
                    0.0,                     # sim_changed_72h
                    0.0,                     # amount_z_score normal
                    1.0,                     # ratio_to_avg normal
                    0.0,                     # is_new_account
                    0.0,                     # is_dormant_account
                ]
            neighbors.append(neighbor)

        # Padding si moins de MAX_NEIGHBORS voisins
        while len(neighbors) < MAX_NEIGHBORS:
            neighbors.append([0.0] * GNN_INPUT_SIZE)

        return neighbors[:MAX_NEIGHBORS]